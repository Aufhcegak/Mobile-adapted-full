# 立体农业 0.6.6-mobile2 手机版

安装前完全退出游戏。将 VerticalFarming 文件夹放进手机 SMAPI 的 Mods，完整替换 DLL、manifest、assets 和 i18n；保留自己的 config.json，再重启游戏。

农业小屋外墙电脑现在可在门右侧轻触打开；电脑端继续支持右键。外墙电脑仍需先完成对应研究并安装。

安装包不含开发源码、测试探针、config.json 或第三方 DLL。Android 真机触控验收尚未完成。

# Vertical Farming 0.6.6-mobile2

Exit the game, copy the VerticalFarming folder into the mobile SMAPI Mods folder, and replace its DLL, manifest, assets, and i18n. Keep your own config.json, then restart.

Tap the wall computer beside the agricultural shed door on mobile. PC right-click remains supported. The console still requires its research and installation.

The package excludes source code, test probes, config.json, and third-party DLLs. Android hardware touch acceptance remains pending.